/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.course;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author marsh
 */
public class Question extends JFrame{
    
    JFrame frm1 = new JFrame();
    
    JPanel pnl1 = new JPanel();
    
    static JButton teachBtn = new JButton("TEACHER");
    
    static JLabel txt = new JLabel("OR");
    
    static JButton studBtn = new JButton("STUDENT");
    
}