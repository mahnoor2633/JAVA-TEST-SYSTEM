/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.course;

import javax.swing.*;

/**
 *
 * @author marsh
 */
public class Courses extends JFrame{
    
    static JFrame crsFrm = new JFrame();
    
    static JPanel crsPnl = new JPanel();
    
    static JLabel selLbl = new JLabel("Select the courses");
    
    static JButton dataManagementTheory = new JButton("Database Management System Theory");
    
    static JButton dataManagementLab = new JButton("Database Management System Lab");
    
    static JButton objOrntProgTheory = new JButton("Object Oriented Programming Theory");
    
    static JButton objOrntProgLab = new JButton("Object Oriented Programming Lab");
    
    static JButton opSysLab = new JButton("Operating System Lab");
    
    static JButton opSysTheory = new JButton("Operating System Theory");
    
    static JButton softDesArch = new JButton("Software Design and Architecture");
    
}
